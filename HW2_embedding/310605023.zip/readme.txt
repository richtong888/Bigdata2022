This is 310605023 hw2 ipynb
if you want to do training , please use shift and enter till 'train' this part.
also , if you want to export npy file or pth , the following 'save npy' and 'save pth ' can help you save your file and weight.
At the final part of the code is the referances for Simclr and Bigdata lab1.
Enjoy yourself!

Written by Richtong in 2022 04 27
